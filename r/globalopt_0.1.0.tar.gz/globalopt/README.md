# globalopt R package skeleton

This directory contains a CRAN-style R package scaffold implemented directly for the R ecosystem.

Included:

- `furasn()` benchmark objective
- `lp_tau_point()` low-discrepancy sampler
- global methods: `mig2()`, `bayes1()`, `lpmin()`, `glopt()`, `lbayes()`
- additional methods: `unt()`, `exkor()`, `extr()`, `mivar4()`, `flexi()`, `reqp()`
- analysis helpers: `anal1()`, `anal2()`
- local minimizer adapters for `stats::optim`, `optimx`, `nloptr`, and `minqa`
- benchmark helpers: `benchmark_functions()`, `benchmark_optimizers()`, `run_benchmarks()`

Benchmark example:

```r
library(globalopt)
tbl <- run_benchmarks(dimensions = c(2L, 10L), budgets = c(1000L), seeds = 1:5)
write_benchmark_csv(tbl, "benchmark_results.csv")
write_benchmark_markdown(tbl, "benchmark_results.md")
print(head(tbl))
```

Example:

```r
library(globalopt)
a <- c(-0.25, -0.125)
b <- c(0.5, 0.625)
result <- bayes1(a, b, evaluations = 200, initial_points = 20, objective = furasn,
                 local_minimizer = "optim")
print(result$best_f)
```
