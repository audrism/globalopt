C MINIMUM Copyright (c) 1989, by Jonas Mockus
C You may give out copies of this software; for conditions see the
C file COPYING included with this distribution.                    

C Modified from I1MACH.FOR. 1991, Audris Mockus.

      INTEGER FUNCTION I1MACH(I)
C     PORT FOR MIPS COMPUTER (DECstation 3100, 5000 based on float.h)
      INTEGER*4 IMACH(16)
      DATA IMACH/5,6,7,6,32,4,
     *2,31,2147483647,2,24,-125,128,53,-1021,1024/
      IF(I.LT.1.OR.I.GT.16) GO TO 1
      I1MACH=IMACH(I)
      RETURN
    1 NERR=IMACH(4)
      WRITE(NERR,2) I
    2 FORMAT (/2X,41H**E R R O R  I N  I 1 M A C H** VALUE I =,I3,
     C11H INFEASIBLE)
      STOP
      END
      REAL FUNCTION R1MACH(I)
      DIMENSION RMACH(5),IEQ(5)
c     EQUIVALENCE(RMACH(1),IEQ(1))
      DATA rmach/1.17549435e-38,3.40282347e+38,
     *5.96046447753e-8,1.19209290e-07,0.30103e+00/
      IF (I.LT.1.OR.I.GT.5) GO TO 1
      R1MACH=RMACH(I)
      RETURN
    1 NERR=I1MACH(4)
      WRITE(NERR,2) I
    2 FORMAT (/2X,41H**E R R O R  I N  R 1 M A C H** VALUE I =,I2,
     C11H INFEASIBLE)
      STOP
      END
      DOUBLE PRECISION FUNCTION D1MACH(I)
      DOUBLE PRECISION DMACH(5)
      INTEGER IEQ(5)
c     EQUIVALENCE (DMACH(1),IEQ(1))
      DATA dmach/2.2250738585072014d-308, 1.7976931348623157d+308,
     C1.11102230246251565d-16,2.2204460492503131d-16,
     C0.3010299956639812/
      IF (I.LT.1.OR.I.GT.5) GO TO 1
      D1MACH=DMACH(I)
      RETURN
    1 NERR =I1MACH(4)
      WRITE (NERR,2) I
    2 FORMAT (/2X,41H**E R R O R  I N  D 1 M A C H** VALUE I =,I2,
     C11H INFEASIBLE)
      STOP
      END
      FUNCTION ATS(J)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
      COMMON /ATT/X(15)
      X1=X(1)+X(15)
      IF (X1.GT.1.) X1=X1-1.
      DO 1 I=2,15
    1 X(I-1)=X(I)
      X(15)=X1
      ATS=X1
      RETURN
      END
      SUBROUTINE LPTAU(C,N,X)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
C
C      PORTABLE GENERATOR OF LP-SEQUENCES
C      INPUT:
C      C    - NUMBER OF POINT
C      OUTPUT
C      X(N) - GENERATED POINT
C      N    - DIMENSION OF X
C
      REAL*8 X(N),NR(400),A1(100),A2(100),A3(80),A4(60),A5(60)
      EQUIVALENCE(A1(1),NR(1)),(A2(1),NR(101)),(A3(1),NR(201)),
     *(A4(1),NR(281)),(A5(1),NR(341))
      DATA A1/20*1.,1.,3.,1.,3.,1.,3.,1.,3.,3.,1.,3.,1.,3.,1.,3.,1.,
     *1.,3.,1.,3.,1.,5.,7.,7.,5.,1.,3.,3.,7.,5.,5.,7.,7.,1.,3.,3.,7.,
     *5.,1.,1.,1.,15.,11.,5.,3.,1.,7.,9.,13.,11.,1.,3.,7.,9.,5.,13.,
     *13.,11.,3.,15.,1.,17.,13.,7.,15.,9.,31.,9.,3.,27.,15.,29.,21.,
     *23.,19.,11.,25.,7.,13.,17./
      DATA A2/1.,51.,61.,43.,51.,59.,47.,57.,35.,53.,19.,51.,61.,37.,
     *33.,7.,5.,11.,39.,63.,1.,85.,67.,49.,125.,25.,109.,43.,89.,69.,
     *113.,47.,55.,97.,3.,37.,83.,103.,27.,13.,1.,255.,79.,147.,141.,
     *89.,173.,43.,9.,25.,115.,97.,19.,97.,197.,101.,255.,29.,203.,
     *65.,1.,257.,465.,439.,177.,321.,181.,225.,235.,103.,411.,233.,
     *59.,353.,329.,463.,385.,111.,475.,451.,1.,771.,721.,1013.,759.,
     *835.,949.,113.,929.,615.,157.,39.,761.,169.,983.,657.,647.,581.,
     *505.,833./
      DATA A3/1.,1285.,823.,727.,267.,833.,471.,1601.,1341.,913.,1725.,
     *2021.,1905.,375.,893.,1599.,415.,605.,819.,975.,1.,3855.,4091.,
     *987.,1839.,4033.,2515.,579.,3863.,977.,3463.,2909.,3379.,1349.,
     *3739.,347.,387.,2881.,2821.,1873.,1.,4369.,4125.,5889.,6929.,3913
     *.,6211.,1731.,1347.,6197.,2817.,5459.,8119.,5121.,7669.,2481.,
     *7101.,2677.,1405.,7423.,1.,13107.,4141.,6915.,16241.,11643.,2147.,
     *11977.,4417.,14651.,9997.,2615.,13207.,13313.,2671.,5201.,11469.,
     *14855.,12165.,5837./
      DATA A4/1.,21845.,28723.,16647.,16565.,18777.,3169.,7241.,5087.,25
     *07.,7451.,13329.,8965.,19457.,18391.,3123.,11699.,721.,709.,20481.
     *,1.,65535.,45311.,49925.,17139.,35225.,35873.,63609.,12631.,27109.
     *,12055.,35887.,9997.,1033.,31161.,32253.,15865.,26903.,41543.,1229
     *1.,1.,65537.,53505.,116487.,82207.,102401.,33841.,81003.,103445.,
     *5205.,44877.,97323.,75591.,62487.,12111.,78043.,49173.,100419.,
     *57545.,86017./
      DATA A5/1.,196611.,250113.,83243.,50979.,45059.,99889.,15595.,1526
     *45.,91369.,24895.,83101.,226659.,250917.,259781.,63447.,147489.,20
     *6167.,77163.,12303.,1.,327685.,276231.,116529.,252717.,36865.,2473
     *15.,144417.,130127.,302231.,508255.,320901.,187499.,234593.,36159.
     *,508757.,81991.,241771.,357231.,299025.,1.,983055.,326411.,715667.
     *,851901.,299009.,1032727.,685617.,775365.,172023.,574033.,810643.,
     *628265.,308321.,232401.,974837.,802875.,987201.,378135.,774207./
      D(X1)=X1-AINT(X1)
      M=1+INT(DLOG(C)/0.693147)
      DO 1 J=1,N
      S=0.
      DO 2 K=1,M
      NS=0
      DO 3 L=K,M
      NN=(L-1)*20+J
      B=NR(NN)
    3 NS=NS+INT(2.*D(C/2.**L))*INT(2.*D(B/2.**(L+1-K)))
      RS=FLOAT(NS)
    2 S=S+D(0.5*RS)/2.**(K-1)
    1 X(J)=S
      RETURN
      END
      BLOCK DATA
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
      COMMON /ATT/X(15)
      DATA X/0.86515,0.90795,0.66155,0.66434,0.56558,0.12332,0.69186,
     C0.03393,0.42502,0.99224,0.88955,0.53758,0.41686,0.42163,0.85181/
      END
      FUNCTION FURASN(X,N)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
      DIMENSION X(N)
      NN=N
      F=0.
      DO 10 I=1,NN
      XI=X(I)
   10 F=F+XI*XI-COS(18.*XI)
      AN=NN
      FURASN=F*(2./AN)
      RETURN
      END
      FUNCTION FUSH5(X,N)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
C     SHEKEL'S FAMILY
      DIMENSION X(N)
      DIMENSION A1(5,4),C1(5)
      DATA A1/4.,1.,8.,6.,3.,4.,1.,8.,6.,7.,4.,1.,8.,6.,3.,4.,1.,8.,6.,
     C7./
      DATA C1/.1,.2,.2,.4,.4/
      F=0.
      DO 1 I=1,5
      F1=C1(I)
      DO 2 J=1,N
      F2=X(J)-A1(I,J)
    2 F1=F1+F2*F2
    1 F=F-1./F1
      FUSH5=F
      RETURN
      END
      FUNCTION FUSH7(X,N)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
C     SHEKEL'S FAMILY
      DIMENSION X(N)
      DIMENSION A1(7,4),C1(7)
      DATA A1/4.,1.,8.,6.,3.,2.,5.,4.,1.,8.,6.,7.,9.,5.,4.,1.,8.,6.,3.,
     C2.,3.,4.,1.,8.,6.,7.,9.,3./
      DATA C1/.1,.2,.2,.4,.4,.6,.3/
      F=0.
      DO 1 I=1,7
      F1=C1(I)
      DO 2 J=1,N
      F2=X(J)-A1(I,J)
    2 F1=F1+F2*F2
    1 F=F-1./F1
      FUSH7=F
      RETURN
      END
      FUNCTION FUSH10(X,N)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
C     SHEKEL'S FAMILY
      DIMENSION X(N)
      DIMENSION A1(10,4),C1(10)
      DATA A1/4.,1.,8.,6.,3.,2.,5.,8.,6.,7.,4.,1.,8.,6.,7.,9.,5.,1.,2.,
     C3.6,4.,1.,8.,6.,3.,2.,3.,8.,6.,7.,4.,1.,8.,6.,7.,9.,3.,1.,2.,3.6/
      DATA C1/.1,.2,.2,.4,.4,.6,.3,.7,.5,.5/
      F=0.
      DO 1 I=1,10
      F1=C1(I)
      DO 2 J=1,N
      F2=X(J)-A1(I,J)
    2 F1=F1+F2*F2
    1 F=F-1./F1
      FUSH10=F
      RETURN
      END
      FUNCTION FUHAR3(X,N)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
C     HARTMAN'S FAMILY
      DIMENSION X(N)
      DIMENSION ALFA(4,3),C1(4),P(4,3)
      DATA ALFA/3.,.1,3.,.1,4*10.,30.,35.,30.,35./
      DATA C1/1.,1.2,3.,3.2/
      DATA P/0.3689,0.4699,0.1091,0.03815,0.117,0.4387,0.8732,0.5743,
     C0.2673,0.7470,0.5547,0.8828/
      F=0.
      DO 1 I=1,4
      F1=0.
      DO 2 J=1,N
      F2=X(J)-P(I,J)
    2 F1=F1-ALFA(I,J)*F2*F2
    1 F=F-C1(I)*EXP(F1)
      FUHAR3=F
      RETURN
      END
      FUNCTION FUHAR6(X,N)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
C     HARTMAN'S FAMILY
      DIMENSION X(N)
      DIMENSION ALFA(4,6),C1(4),P(4,6)
      DATA ALFA/10.,.05,3.,17.,3.,10.,3.5,8.,17.,17.,1.7,.05,3.5,.1,10.,
     C10.,1.7,8.,17.,.1,8.,14.,8.,14./
      DATA C1/1.,1.2,3.,3.2/
      DATA P/0.1312,0.2329,0.2348,0.4047,0.1696,0.4135,0.1451,0.8828,
     C0.5569,0.8307,0.3522,0.8732,0.0124,0.3736,0.2883,0.5743,0.8283,
     C0.1004,0.3047,0.1091,0.5886,0.9991,0.6650,0.0381/
      F=0.
      DO 1 I=1,4
      F1=0.
      DO 2 J=1,N
      F2=X(J)-P(I,J)
    2 F1=F1-ALFA(I,J)*F2*F2
    1 F=F-C1(I)*EXP(F1)
      FUHAR6=F
      RETURN
      END
      FUNCTION FUBRAN(X,N)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
C     BRANIN FUNCTION
      DIMENSION X(N)
      X1 = X(1)
      X2 = X(2)
      FUBRAN=(X2-0.1292*X1*X1+1.59155*X1-6.)**2+9.60211*COS(X1)+10.
      RETURN
      END
      FUNCTION FUGOLD(X,N)
      IMPLICIT INTEGER*4 (I - N)
      IMPLICIT REAL*8    (A - H, O - Z)
C     GOLDSTEIN AND PRICE FUNCTION
      DIMENSION X(N)
      X1=X(1)
      X2=X(2)
      X3=X1*X1
      X4=X2*X2
      X5=X1*X2
      FUGOLD=(1.+(X1+X2+1.)**2*(19.-14.*X1+3.*X3-14.*X2+6.*X5+3.*X4))*
     C(30.+(2.*X1-3.*X2)**2*(18.-32.*X1+12.*X3+48.*X2-36.*X5+27.*X4))
      RETURN
      END






